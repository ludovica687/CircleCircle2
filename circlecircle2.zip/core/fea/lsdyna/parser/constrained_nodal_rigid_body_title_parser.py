from circlecircle2.core.fea.parser import Parser
from circlecircle2.core.fea.lsdyna.keywords.constrained_nodal_rigid_body import ConstrainedNodalRigidBody


class ConstrainedNodalRigidBodyTitleParser(Parser):
    def __init__(self):
        super().__init__()

        self.version = {
            "12.0": self._12p0,
            "13.0": self._12p0,
        }

    def _12p0(self, line_raw):
        if self.line_number == 0:
            name_raw = line_raw.strip()

            self.temp.append(name_raw)

            self.line_number = 1

            return

        if self.line_number == 1:
            name_raw = self.temp[0]
            pid_raw = line_raw[0:10].strip()
            cid_raw = line_raw[10:20].strip()
            sid_raw = line_raw[20:30].strip()
            pnode_raw = line_raw[30:40].strip()
            iprt_raw = line_raw[40:50].strip()
            drflag_raw = line_raw[50:60].strip()
            rrflag_raw = line_raw[60:70].strip()

            name = name_raw

            pid = pid_raw[1:] if pid_raw.startswith("&") else int(pid_raw)

            if len(cid_raw) > 0:
                cid = cid_raw[1:] if cid_raw.startswith("&") else int(cid_raw)
            else:
                cid = 0

            sid = sid_raw[1:] if sid_raw.startswith("&") else int(sid_raw)

            if len(pnode_raw) > 0:
                pnode = pnode_raw[1:] if pnode_raw.startswith("&") else int(pnode_raw)
            else:
                pnode = 0

            if len(iprt_raw) > 0:
                iprt = iprt_raw[1:] if iprt_raw.startswith("&") else int(iprt_raw)
            else:
                iprt = 0

            if len(drflag_raw) > 0:
                drflag = drflag_raw[1:] if drflag_raw.startswith("&") else int(drflag_raw)
            else:
                drflag = 0

            if len(rrflag_raw) > 0:
                rrflag = rrflag_raw[1:] if rrflag_raw.startswith("&") else int(rrflag_raw)
            else:
                rrflag = 0

            self.dataframe.constrained_nodal_rigid_body[pid] = ConstrainedNodalRigidBody(uid=pid,
                                                                                         cid=cid,
                                                                                         sid=sid,
                                                                                         pnode=pnode,
                                                                                         iprt=iprt,
                                                                                         drflag=drflag,
                                                                                         rrflag=rrflag,
                                                                                         name=name)

            if sid in self.dataframe.set_node_list:
                self.dataframe.constrained_nodal_rigid_body[pid].nset = self.dataframe.set_node_list[sid]

            return
