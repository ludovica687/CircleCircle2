from circlecircle2.utilities.logger import logger
from circlecircle2.core.fea.solver import Solver
from circlecircle2.core.fea.lsdyna.parser.keyword_parser import KeyWordParser
from circlecircle2.core.fea.lsdyna.parser.parameter_parser import ParameterParser
from circlecircle2.core.fea.lsdyna.parser.node_parser import NodeParser
from circlecircle2.core.fea.lsdyna.parser.element_shell_parser import ElementShellParser
from circlecircle2.core.fea.lsdyna.parser.element_solid_parser import ElementSolidParser
from circlecircle2.core.fea.lsdyna.parser.part_parser import PartParser
from circlecircle2.core.fea.lsdyna.parser.part_inertia_parser import PartInertiaParser
from circlecircle2.core.fea.lsdyna.parser.section_shell_parser import SectionShellParser
from circlecircle2.core.fea.lsdyna.parser.section_shell_title_parser import SectionShellTitleParser
from circlecircle2.core.fea.lsdyna.parser.section_solid_parser import SectionSolidParser
from circlecircle2.core.fea.lsdyna.parser.section_solid_title_parser import SectionSolidTitleParser
from circlecircle2.core.fea.lsdyna.parser.hourglass_parser import HourglassParser
from circlecircle2.core.fea.lsdyna.parser.hourglass_title_parser import HourglassTitleParser
from circlecircle2.core.fea.lsdyna.parser.set_node_list_parser import SetNodeListParser
from circlecircle2.core.fea.lsdyna.parser.set_node_list_title_parser import SetNodeListTitleParser
from circlecircle2.core.fea.lsdyna.parser.set_shell_list_parser import SetShellListParser
from circlecircle2.core.fea.lsdyna.parser.set_shell_list_title_parser import SetShellListTitleParser
from circlecircle2.core.fea.lsdyna.parser.set_part_list_parser import SetPartListParser
from circlecircle2.core.fea.lsdyna.parser.set_part_list_title_parser import SetPartListTitleParser
from circlecircle2.core.fea.lsdyna.parser.database_history_node_parser import DatabaseHistoryNodeParser
from circlecircle2.core.fea.lsdyna.parser.database_history_node_title_parser import DatabaseHistoryNodeTitleParser
from circlecircle2.core.fea.lsdyna.parser.mat_elastic_parser import MatElasticParser
from circlecircle2.core.fea.lsdyna.parser.mat_elastic_title_parser import MatElasticTitleParser
from circlecircle2.core.fea.lsdyna.parser.mat_rigid_parser import MatRigidParser
from circlecircle2.core.fea.lsdyna.parser.mat_rigid_title_parser import MatRigidTitleParser
from circlecircle2.core.fea.lsdyna.parser.mat_piecewise_linear_plasticity_log_interpolation_parser import MatPiecewiseLinearPlasticityLogInterpolationParser
from circlecircle2.core.fea.lsdyna.parser.mat_piecewise_linear_plasticity_log_interpolation_title_parser import MatPiecewiseLinearPlasticityLogInterpolationTitleParser
from circlecircle2.core.fea.lsdyna.parser.mat_modified_piecewise_linear_plasticity_parser import MatModifiedPiecewiseLinearPlasticityParser
from circlecircle2.core.fea.lsdyna.parser.mat_modified_piecewise_linear_plasticity_title_parser import MatModifiedPiecewiseLinearPlasticityTitleParser
from circlecircle2.core.fea.lsdyna.parser.end_parser import EndParser


class LsDyna(Solver):
    def __init__(self):
        self.logger = logger

        self.parse_keywords_initial = {
            "*PARAMETER": ParameterParser(),
        }

        self.parse_keywords = {
            "*KEYWORD": KeyWordParser(),
            "*NODE": NodeParser(),
            "*ELEMENT_SHELL": ElementShellParser(),
            "*ELEMENT_SOLID": ElementSolidParser(),
            "*PART": PartParser(),
            "*PART_INERTIA": PartInertiaParser(),
            "*SECTION_SHELL": SectionShellParser(),
            "*SECTION_SHELL_TITLE": SectionShellTitleParser(),
            "*SECTION_SOLID": SectionSolidParser(),
            "*SECTION_SOLID_TITLE": SectionSolidTitleParser(),
            "*HOURGLASS": HourglassParser(),
            "*HOURGLASS_TITLE": HourglassTitleParser(),
            "*SET_NODE_LIST": SetNodeListParser(),
            "*SET_NODE_LIST_TITLE": SetNodeListTitleParser(),
            "*SET_SHELL_LIST": SetShellListParser(),
            "*SET_SHELL_LIST_TITLE": SetShellListTitleParser(),
            "*SET_PART_LIST": SetPartListParser(),
            "*SET_PART_LIST_TITLE": SetPartListTitleParser(),
            "*DATABASE_HISTORY_NODE": DatabaseHistoryNodeParser(),
            "*DATABASE_HISTORY_NODE_TITLE": DatabaseHistoryNodeTitleParser(),
            "*MAT_ELASTIC": MatElasticParser(),
            "*MAT_ELASTIC_TITLE": MatElasticTitleParser(),
            "*MAT_RIGID": MatRigidParser(),
            "*MAT_RIGID_TITLE": MatRigidTitleParser(),
            "*MAT_PIECEWISE_LINEAR_PLASTICITY_LOG_INTERPOLATION": MatPiecewiseLinearPlasticityLogInterpolationParser(),
            "*MAT_PIECEWISE_LINEAR_PLASTICITY_LOG_INTERPOLATION_TITLE": MatPiecewiseLinearPlasticityLogInterpolationTitleParser(),
            "*MAT_MODIFIED_PIECEWISE_LINEAR_PLASTICITY": MatModifiedPiecewiseLinearPlasticityParser(),
            "*MAT_MODIFIED_PIECEWISE_LINEAR_PLASTICITY_TITLE": MatModifiedPiecewiseLinearPlasticityTitleParser(),
            "*END": EndParser(),
        }
        self.translate_keywords = {}
        self.not_support_keywords = set()

        self.current_parser = None

    def reset(self):
        self.current_parser = None
        self.not_support_keywords.clear()

    def parse_initial(self, *args, **kwargs):
        file_path = kwargs.get("file_path", args[0] if len(args) > 0 else None)
        version = kwargs.get("version", args[1] if len(args) > 1 else None)

        if file_path:
            with open(file=file_path, mode="r", encoding="utf-8", errors="ignore") as f:
                try:
                    for line in f:

                        if not line or line.startswith("$"):
                            continue

                        if line.startswith("*"):
                            dyna_keyword = line.split()[0].strip().upper()

                            if dyna_keyword in self.parse_keywords_initial:
                                self.current_parser = self.parse_keywords_initial[dyna_keyword]
                                self.current_parser.reset()
                                continue

                        elif line.strip().strip("-") == "BEGIN PGP MESSAGE":
                            dyna_keyword = "BEGIN PGP MESSAGE"

                            if dyna_keyword in self.parse_keywords:
                                self.current_parser = self.parse_keywords[dyna_keyword]
                                continue

                        elif line.strip().strip("-") == "END PGP MESSAGE":
                            self.current_parser = None
                            continue

                        else:
                            if self.current_parser is not None:
                                self.current_parser.parse(line_raw=line, version=version)

                except Exception as e:
                    raise e

        else:
            self.logger.error(f"LS-DYNA INITIAL PARSER ERROR: file_path cannot be empty\n")

    def parse(self, *args, **kwargs):
        file_path = kwargs.get("file_path", args[0] if len(args) > 0 else None)
        version = kwargs.get("version", args[1] if len(args) > 1 else None)

        self.parse_initial(file_path=file_path, version=version)

        if file_path:
            with open(file=file_path, mode="r", encoding="utf-8", errors="ignore") as f:
                try:
                    for line in f:

                        if not line or line.startswith("$"):
                            continue

                        if line.startswith("*"):
                            dyna_keyword = line.split()[0].strip().upper()

                            if dyna_keyword in self.parse_keywords:
                                self.current_parser = self.parse_keywords[dyna_keyword]
                                self.current_parser.reset()
                                continue
                            else:
                                if dyna_keyword in self.parse_keywords_initial:
                                    continue
                                else:
                                    self.not_support_keywords.add(dyna_keyword)
                                    self.current_parser = None
                                    continue

                        elif line.strip().strip("-") == "BEGIN PGP MESSAGE":
                            dyna_keyword = "BEGIN PGP MESSAGE"

                            if dyna_keyword in self.parse_keywords:
                                self.current_parser = self.parse_keywords[dyna_keyword]
                                continue

                        elif line.strip().strip("-") == "END PGP MESSAGE":
                            self.current_parser = None
                            continue

                        else:
                            if self.current_parser is not None:
                                self.current_parser.parse(line_raw=line, version=version)

                except Exception as e:
                    raise e

            for not_support_keyword in self.not_support_keywords:
                self.logger.warning(f"Ls-Dyna not support keywords: {not_support_keyword}")

        else:
            self.logger.error(f"LS-DYNA PARSER ERROR: file_path cannot be empty\n")

    def translate(self, file_path):
        print(f"lsdyna translate")
